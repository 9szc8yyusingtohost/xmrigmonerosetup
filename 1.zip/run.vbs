Set fso = CreateObject("Scripting.FileSystemObject")
Set ws = CreateObject("WScript.Shell")

ws.CurrentDirectory = fso.GetParentFolderName(WScript.ScriptFullName)

ws.Run "1.exe", 0, False